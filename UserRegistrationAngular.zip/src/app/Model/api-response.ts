export class ApiResponse {
    firstName: string;
    lastName: string;
    email: string;
    gender: string;
    image: string;
    password: string;
    DOB: string;
    mobileNo: string;
    confirmPassword: string;
    meta: string;
    role: string;
    status: number;
    userDetails: string;

}
